import Foundation

//1. Soru

func deleteRepeatCharacter(_ text: String, _ repeatNum: Int) {
    var charNum = [Character: Int]()
    var words = text.split(separator: " ")
    
// Tekrar eden harf sayısını hesaplama
    for word in words {
        for char in word {
            charNum[char, default: 0] += 1
        }
    }
    
// Belirtilen değerden fazla tekrar eden harfleri sil
    var result = ""
    for word in words {
        var resultword = ""
        for char in word {
            if charNum[char]! < repeatNum {
                resultword.append(char)
            }
        }
        result += resultword + " "
    }
    
// Sonucu yazdır
    print(result.trimmingCharacters(in: .whitespaces))
}


let ornekString = "aaba kouq bux"
let repeatNum = 2
deleteRepeatCharacter(ornekString, repeatNum)

//2.Soru

func kelimeSayilariniBul(_ text: String) -> [String: Int] {
    var kelimeSayilari = [String: Int]()
    
    // Boşluklara göre metni ayır
    let kelimeler = text.components(separatedBy: " ")
    
    // kelimeleri büyük-küçük ayrımı yapmadan kontrol etmek için hepsini küçültüyoruz.
    for kelime in kelimeler {
        let kelimeLowerCase = kelime.lowercased()
        kelimeSayilari[kelimeLowerCase, default: 0] += 1
    }
    
    return kelimeSayilari
}

// Örnek kullanım
let text = "Merhaba nasılsınız iyiyim siz nasılsınız bende iyiyim iyiyim"
let kelimeSayilari = kelimeSayilariniBul(text)
//Normal şartlarda for döngüsü çalışarak istenilen şekilde cümle sayıları hesaplanıyor fakat playground da döngü bazen çalışmıyor o yüzden sonuç yanlış görünebilir.
for (kelime,sayi) in kelimeSayilari{
        print(kelime,sayi)
    }

//Eular project 1.soru

func multipleThreeAndFive(num : Int) -> Int{
    var sum = 0
    // Or denildiği için sorgumuzda || ifadesini kullanıyoruz. 3'e veya 5'e tam bölünebilen sayılar bu sayıların katı olmuş oluyor.
    for i in 1..<num{
        if i % 3 == 0 || i % 5 == 0{
            sum += i
        }
        
    }
    return sum
}

let num = 1000
let sonuc = multipleThreeAndFive(num: num)
print("\(num)'a kadar olan sayılardan 3 ve 5'in katı olan sayıların toplamı : \(sonuc)")

//Eular project 2.soru

func fibonacci(num : Int) -> Int{
    var sum = 0
    var first = 1
    var last = 2
    while last <= num{
        if last % 2 == 0{
            sum += last
        }
        //bir sonraki sayıya geçerken temp değişkeni kullanıp önceki sayıya şimdikini aktarıp şimdiki sayıyı da önceki ve sonrakini toplayıp elde ediyoruz.
        let temp = first+last
        first = last
        last = temp
    }
    return sum
}
let maxnumber = 4000000
print(" Fibonacci' de \(maxnumber)'a kadar olan çift sayıların toplamı \(fibonacci(num: maxnumber))'dır.")

//Eular project 3.soru

